package com.instagram.backend.domain.Post.controller;

import com.instagram.backend.domain.Post.dto.CommentDTO;
import com.instagram.backend.domain.Post.dto.CreateCommentDTO;
import com.instagram.backend.domain.Post.dto.CreatePostDTO;
import com.instagram.backend.domain.Post.dto.PostDTO;
import com.instagram.backend.domain.Post.service.PostService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/v1/post")
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class PostController {

    private final PostService postService;

    @PostMapping
    @Transactional
    public ResponseEntity<String> createPost(CreatePostDTO createPostDTO, Principal principal) {
        postService.createPost(createPostDTO, principal);

        return ResponseEntity.ok("포스트 업로드에 성공했습니다.");
    }

    @GetMapping
    public ResponseEntity<Page<PostDTO>> getPosts(Principal principal, Pageable pageable) {
        Page<PostDTO> postDTOPage = postService.getPosts(principal, pageable);

        return ResponseEntity.ok(postDTOPage);
    }

    @PostMapping("/{postId}/like")
    @Transactional
    public ResponseEntity<?> likePost(@PathVariable Long postId, Principal principal) {
        postService.likePost(postId, principal);

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/{postId}/like")
    @Transactional
    public ResponseEntity<?> unlikePost(@PathVariable Long postId, Principal principal) {
        postService.unlikePost(postId, principal);

        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @GetMapping("/{postId}/comment")
    public ResponseEntity<List<CommentDTO>> getComments(@PathVariable Long postId) {
        List<CommentDTO> commentDTOList = postService.getComments(postId);

        return ResponseEntity.ok(commentDTOList);
    }

    @PostMapping("/{postId}/comment")
    @Transactional
    public ResponseEntity<?> createComment(@PathVariable Long postId, @RequestBody CreateCommentDTO createCommentDTO, Principal principal) {
        postService.createComment(postId, createCommentDTO, principal);

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
}
