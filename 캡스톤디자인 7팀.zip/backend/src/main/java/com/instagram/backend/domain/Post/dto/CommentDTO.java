package com.instagram.backend.domain.Post.dto;

import com.instagram.backend.domain.Post.domain.Comment;
import com.instagram.backend.domain.User.domain.User;
import com.instagram.backend.domain.User.dto.UserDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CommentDTO {

    private String message;
    private UserDTO user;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static CommentDTO fromComment(Comment comment) {
        return CommentDTO.builder()
                .message(comment.getMessage())
                .user(UserDTO.fromUser(comment.getUser()))
                .createdAt(comment.getCreatedAt())
                .updatedAt(comment.getUpdatedAt())
                .build();
    }
}
