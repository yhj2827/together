package com.instagram.backend.domain.Post.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreatePostDTO {

    private MultipartFile photo;
    @NotEmpty
    private String caption;
    @NotEmpty
    private String location;
    private List<String> tags;
}
