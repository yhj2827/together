package com.instagram.backend.domain.Post.dto;

import com.instagram.backend.domain.Post.domain.Like;
import com.instagram.backend.domain.Post.domain.Post;
import com.instagram.backend.domain.User.dto.UserDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PostDTO {

    private Long id;
    private UserDTO author;
    private String photo;
    private String caption;
    private String location;
    private List<UserDTO> likedUsers;
    private Boolean isLiked;
    private List<CommentDTO> comments;
    private List<UserDTO> tags;

    public static PostDTO fromPost(Post post, Principal principal) {
        return PostDTO.builder()
                .id(post.getId())
                .author(UserDTO.fromUser(post.getAuthor()))
                .photo(post.getPhoto())
                .caption(post.getCaption())
                .location(post.getLocation())
                .likedUsers(post.getLikes().stream().map(like -> UserDTO.fromUser(like.getUser())).collect(Collectors.toList()))
                .isLiked(post.getLikes().stream().anyMatch(like -> like.getUser().getUsername().equals(principal.getName())))
                .comments(post.getComments().stream().map(CommentDTO::fromComment).collect(Collectors.toList()))
                .tags(post.getTags().stream().map(tag -> UserDTO.fromUser(tag.getUser())).collect(Collectors.toList()))
                .build();
    }
}
