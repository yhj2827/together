package com.instagram.backend.domain.Post.repository;

import com.instagram.backend.domain.Post.domain.Like;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LikeRepository extends JpaRepository<Like, Long> {
}
