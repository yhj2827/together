package com.instagram.backend.domain.Post.repository;

import com.instagram.backend.domain.Post.domain.Post;
import com.instagram.backend.domain.User.domain.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PostRepository extends JpaRepository<Post, Long> {

    Page<Post> findByAuthorIn(List<User> followings, Pageable pageable);
}
