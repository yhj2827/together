package com.instagram.backend.domain.Post.service;

import com.instagram.backend.domain.Post.domain.Comment;
import com.instagram.backend.domain.Post.domain.Like;
import com.instagram.backend.domain.Post.domain.Post;
import com.instagram.backend.domain.Post.domain.Tag;
import com.instagram.backend.domain.Post.dto.CommentDTO;
import com.instagram.backend.domain.Post.dto.CreateCommentDTO;
import com.instagram.backend.domain.Post.dto.CreatePostDTO;
import com.instagram.backend.domain.Post.dto.PostDTO;
import com.instagram.backend.domain.Post.repository.CommentRepository;
import com.instagram.backend.domain.Post.repository.LikeRepository;
import com.instagram.backend.domain.Post.repository.PostRepository;
import com.instagram.backend.domain.User.domain.Follow;
import com.instagram.backend.domain.User.domain.User;
import com.instagram.backend.domain.User.repository.UserRepository;
import com.instagram.backend.global.exception.CustomErrorCode;
import com.instagram.backend.global.exception.CustomException;
import com.instagram.backend.global.s3.S3Uploader;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class PostService {

    private final PostRepository postRepository;
    private final UserRepository userRepository;
    private final LikeRepository likeRepository;
    private final CommentRepository commentRepository;
    private final S3Uploader s3Uploader;

    @Transactional
    public void createPost(CreatePostDTO createPostDTO, Principal principal) {
        String username = principal.getName();
        User author = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다."));

        List<Tag> tags = new ArrayList<>();

        if (createPostDTO.getTags() != null) {
            for (String taggedUsername : createPostDTO.getTags()) {
                User taggedUser = userRepository.findByUsername(taggedUsername).orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다."));

                Tag tag = Tag.builder()
                        .user(taggedUser)
                        .build();

                tags.add(tag);
            }
        }

        String fileKey = s3Uploader.uploadFile(createPostDTO.getPhoto());
        String fileUrl = s3Uploader.getFileUrl(fileKey);

        Post post = Post.builder()
                .photo(fileUrl)
                .caption(createPostDTO.getCaption())
                .location(createPostDTO.getLocation())
                .author(author)
                .tags(tags)
                .build();
        postRepository.save(post);
    }

    public Page<PostDTO> getPosts(Principal principal, Pageable pageable) {
        String username = principal.getName();
        User user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다."));

        PageRequest pageRequest = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.DESC, "createdAt"));

        List<User> followings = user.getFollowings().stream()
                .map(Follow::getFollowedUser)
                .collect(Collectors.toList());
        followings.add(user);

        Page<Post> postPage = postRepository.findByAuthorIn(followings, pageRequest);

        return new PageImpl<>(postPage.stream()
                .map(post -> PostDTO.fromPost(post, principal))
                .collect(Collectors.toList()));
    }

    @Transactional
    public void likePost(Long postId, Principal principal) {
        Post post = postRepository.findById(postId).orElseThrow(() -> new CustomException(CustomErrorCode.POST_NOT_FOUND));
        User user = userRepository.findByUsername(principal.getName()).orElseThrow(() -> new CustomException(CustomErrorCode.USER_NOT_FOUND));

        likeRepository.save(Like.builder()
                .user(user)
                .post(post)
                .build());
    }

    @Transactional
    public void unlikePost(Long postId, Principal principal) {
        Post post = postRepository.findById(postId).orElseThrow(() -> new CustomException(CustomErrorCode.POST_NOT_FOUND));

        Optional<Like> likeOptional = post.getLikes().stream().filter(l -> l.getUser().getUsername().equals(principal.getName())).findFirst();

        if (likeOptional.isPresent()) {
            likeRepository.delete(likeOptional.get());
        } else {
            throw new CustomException(CustomErrorCode.LIKE_NOT_FOUND);
        }
    }

    public List<CommentDTO> getComments(Long postId) {
        List<Comment> commentList = commentRepository.findByPostId(postId);

        return commentList.stream().map(CommentDTO::fromComment).collect(Collectors.toList());
    }

    @Transactional
    public void createComment(Long postId, CreateCommentDTO createCommentDTO, Principal principal) {
        Post post = postRepository.findById(postId).orElseThrow(() -> new CustomException(CustomErrorCode.POST_NOT_FOUND));
        User user = userRepository.findByUsername(principal.getName()).orElseThrow(() -> new CustomException(CustomErrorCode.USER_NOT_FOUND));

        commentRepository.save(Comment.builder()
                .post(post)
                .user(user)
                .message(createCommentDTO.getMessage())
                .build());
    }
}
