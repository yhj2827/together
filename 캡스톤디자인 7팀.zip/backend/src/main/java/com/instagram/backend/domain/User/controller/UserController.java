package com.instagram.backend.domain.User.controller;

import com.instagram.backend.domain.User.dto.CreateUserDTO;
import com.instagram.backend.domain.User.dto.FollowUserDTO;
import com.instagram.backend.domain.User.dto.LoginDTO;
import com.instagram.backend.domain.User.dto.UserDTO;
import com.instagram.backend.domain.User.service.UserService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.awt.print.Pageable;
import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/v1/user")
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UserController {

    private final UserService userService;
    @Value("${spring.jwt.cookie-valid-time}")
    private Integer cookieValidTime;

    @PostMapping("/join")
    @Transactional
    public ResponseEntity<UserDTO> createUser(@RequestBody CreateUserDTO createUserDTO) {
        UserDTO userDTO = userService.createUser(createUserDTO);

        return ResponseEntity.ok(userDTO);
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginDTO loginDTO, HttpServletResponse response) {
        String jwtToken = userService.login(loginDTO);

        Cookie cookie = new Cookie("jwtToken", jwtToken);
        cookie.setHttpOnly(true);
        cookie.setPath("/");
        cookie.setMaxAge(cookieValidTime);
        response.addCookie(cookie);

        return ResponseEntity.ok("로그인 성공");
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletResponse response) {
        Cookie cookie = new Cookie("jwtToken", null);
        cookie.setHttpOnly(true);
        cookie.setPath("/");
        cookie.setMaxAge(0);
        response.addCookie(cookie);

        return ResponseEntity.ok().build();
    }

    @GetMapping("/status")
    public ResponseEntity<String> status(Principal principal) {
        return ResponseEntity.ok(principal.getName());
    }

    @GetMapping("/suggestions")
    public ResponseEntity<List<UserDTO>> getSuggestions(Principal principal) {
        List<UserDTO> suggestions = userService.getSuggestions(principal);

        return ResponseEntity.ok(suggestions);
    }

    @PostMapping("/follows")
    @Transactional
    public ResponseEntity<String> follow(@RequestBody FollowUserDTO followUserDTO, Principal principal) {
        userService.follow(followUserDTO, principal);

        return ResponseEntity.ok("User successfully followed");
    }

    @DeleteMapping("/follows")
    @Transactional
    public ResponseEntity<String> unfollow(@RequestBody FollowUserDTO followUserDTO, Principal principal) {
        userService.unfollow(followUserDTO, principal);

        return ResponseEntity.ok("User successfully unfollowed");
    }
}
