package com.instagram.backend.domain.User.domain;

import com.instagram.backend.domain.BaseTimeEntity;
import com.instagram.backend.domain.Post.domain.Post;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Entity
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long id;

    private String username;
    private String password;
    private String phone;
    private String gender;

    private String avatar;
    private String bio;
    private String website;

    @OneToMany(mappedBy = "author")
    private List<Post> posts = new ArrayList<>();

    @OneToMany(mappedBy = "followingUser")
    private List<Follow> followings = new ArrayList<>();

    @OneToMany(mappedBy = "followedUser")
    private List<Follow> followers = new ArrayList<>();
}
