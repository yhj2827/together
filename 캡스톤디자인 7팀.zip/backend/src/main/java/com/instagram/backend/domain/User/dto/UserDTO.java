package com.instagram.backend.domain.User.dto;

import com.instagram.backend.domain.User.domain.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserDTO {

    private String username;
    private String phone;
    private String gender;
    private String avatar;
    private String bio;
    private String website;

    public static UserDTO fromUser(User user) {
        return UserDTO.builder()
                .username(user.getUsername())
                .phone(user.getPhone())
                .gender(user.getGender())
                .avatar(user.getAvatar())
                .bio(user.getBio())
                .website(user.getWebsite())
                .build();
    }
}
