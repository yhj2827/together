package com.instagram.backend.domain.User.repository;

import com.instagram.backend.domain.User.domain.Follow;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FollowRepository extends JpaRepository<Follow, Long> {
}
