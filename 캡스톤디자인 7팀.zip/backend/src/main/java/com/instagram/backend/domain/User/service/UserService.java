package com.instagram.backend.domain.User.service;

import com.instagram.backend.domain.User.domain.Follow;
import com.instagram.backend.domain.User.domain.User;
import com.instagram.backend.domain.User.dto.CreateUserDTO;
import com.instagram.backend.domain.User.dto.FollowUserDTO;
import com.instagram.backend.domain.User.dto.LoginDTO;
import com.instagram.backend.domain.User.dto.UserDTO;
import com.instagram.backend.domain.User.repository.FollowRepository;
import com.instagram.backend.domain.User.repository.UserRepository;
import com.instagram.backend.global.exception.CustomErrorCode;
import com.instagram.backend.global.exception.CustomException;
import com.instagram.backend.global.security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.Principal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UserService {

    private final UserRepository userRepository;
    private final FollowRepository followRepository;
    private final JwtTokenProvider jwtTokenProvider;

    @Transactional
    public UserDTO createUser(CreateUserDTO createUserDTO) {
        if (userRepository.findByUsername(createUserDTO.getUsername()).isPresent()) {
            throw new CustomException(CustomErrorCode.USERNAME_CONFLICT);
        }
        User user = User.builder()
                .username(createUserDTO.getUsername())
                .password(createUserDTO.getPassword())
                .build();

        userRepository.save(user);

        return UserDTO.fromUser(user);
    }

    public String login(LoginDTO loginDTO) {
        User user = userRepository.findByUsername(loginDTO.getUsername())
                .orElseThrow(() -> new CustomException(CustomErrorCode.USER_NOT_FOUND));
        if (!user.getPassword().equals(loginDTO.getPassword())) {
            throw new CustomException(CustomErrorCode.PASSWORD_INCORRECT);
        }

        return jwtTokenProvider.createToken(loginDTO.getUsername());
    }

    public List<UserDTO> getSuggestions(Principal principal) {
        User user = userRepository.findByUsername(principal.getName())
                .orElseThrow(() -> new CustomException(CustomErrorCode.USER_NOT_FOUND));

        System.out.println("user = " + user.getFollowings().size() + ", " + user.getFollowers().size());

        List<String> excludedUsernames = user.getFollowings().stream().map(follow -> follow.getFollowedUser().getUsername()).collect(Collectors.toList());
        excludedUsernames.add(user.getUsername());

        System.out.println("excludedUsernames = " + excludedUsernames);

        List<User> userList = userRepository.findByUsernameNotIn(excludedUsernames);

        return userList.stream()
                .map(UserDTO::fromUser)
                .collect(Collectors.toList());
    }

    @Transactional
    public void follow(FollowUserDTO followUserDTO, Principal principal) {
        User followingUser = userRepository.findByUsername(principal.getName())
                .orElseThrow(() -> new CustomException(CustomErrorCode.USER_NOT_FOUND));
        User followedUser = userRepository.findByUsername(followUserDTO.getUsername())
                .orElseThrow(() -> new CustomException(CustomErrorCode.USER_NOT_FOUND));

        followRepository.save(Follow.builder()
                .followingUser(followingUser)
                .followedUser(followedUser)
                .build());
    }

    @Transactional
    public void unfollow(FollowUserDTO followUserDTO, Principal principal) {
        User follower = userRepository.findByUsername(principal.getName())
                .orElseThrow(() -> new CustomException(CustomErrorCode.USER_NOT_FOUND));

        Optional<Follow> followOptional = follower.getFollowings()
                .stream()
                .filter(follow -> follow.getFollowedUser().getUsername().equals(followUserDTO.getUsername())).findFirst();

        if (followOptional.isPresent()) {
            followRepository.delete(followOptional.get());
        } else {
            throw new CustomException(CustomErrorCode.FOLLOW_NOT_FOUND);
        }
    }
}
