package com.instagram.backend.global.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

@RequiredArgsConstructor
@Getter
public enum CustomErrorCode {
    USER_NOT_FOUND(HttpStatus.NOT_FOUND, "USER_NOT_FOUND", "사용자를 찾을 수 없습니다."),
    USERNAME_CONFLICT(HttpStatus.CONFLICT, "USERNAME_CONFLICT", "이미 해당 사용자 이름이 존재합니다."),
    PASSWORD_INCORRECT(HttpStatus.UNAUTHORIZED, "PASSWORD_INCORRECT", "비밀번호가 올바르지 않습니다."),
    FOLLOW_NOT_FOUND(HttpStatus.NOT_FOUND, "FOLLOW_NOT_FOUND", "팔로우 관계가 없습니다."),
    POST_NOT_FOUND(HttpStatus.NOT_FOUND, "POST_NOT_FOUND", "포스트가 존재하지 않습니다."),
    LIKE_NOT_FOUND(HttpStatus.NOT_FOUND, "LIKE_NOT_FOUND", "좋아요가 존재하지 않습니다.");

    private final HttpStatus httpStatus;
    private final String errorType;
    private final String detail;
}
