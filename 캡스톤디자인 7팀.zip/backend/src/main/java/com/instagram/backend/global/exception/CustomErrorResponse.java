package com.instagram.backend.global.exception;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class CustomErrorResponse {
    private String errorType;
    private String message;
}
