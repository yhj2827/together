package com.instagram.backend.global.exception;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.LinkedHashMap;
import java.util.Map;

@ControllerAdvice
@Slf4j
public class CustomExceptionHandler {

    @ExceptionHandler(CustomException.class)
    public ResponseEntity<CustomErrorResponse> handleException(CustomException e, HttpServletRequest request) {
        return new ResponseEntity<>(CustomErrorResponse.builder()
                .errorType(e.getCustomErrorCode().getErrorType())
                .message(e.getMessage())
                .build(), e.getCustomErrorCode().getHttpStatus());
    }
}
