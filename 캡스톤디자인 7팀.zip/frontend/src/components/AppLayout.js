import React from "react";
import "./AppLayout.scss";
import { Button, Input, Menu } from "antd";
import StoryList from "./StoryList";
import SuggestionList from "./SuggestionList";
import LogoImage from "../assets/logo.png";
import { setLogout, useAppContext } from "../store";
import { Link, useNavigate } from "react-router-dom";
import axios from "../utils/AxiosInstance";

function getItem(label, key, icon, children, type) {
  return {
    key,
    icon,
    children,
    label,
    type,
  };
}

const AppLayout = ({ children }) => {
  const navigate = useNavigate();
  const {
    store: { isLoggedIn },
    dispatch,
  } = useAppContext();

  const handleClick = () => {
    navigate("/posts/new");
  };
  return (
    <div className="app">
      <div className="header">
        <div className="page-title">
          <Link to="/">
            <img className="logo" src={LogoImage} alt="logo" />
          </Link>
        </div>
        <div className="topnav">
          {!isLoggedIn && (
            <>
              <Button onClick={() => navigate("/accounts/login")}>
                로그인
              </Button>
              <Button
                type="primary"
                onClick={() => navigate("/accounts/signup")}
              >
                회원가입
              </Button>
            </>
          )}
          {isLoggedIn && (
            <Button
              onClick={async () => {
                try {
                  await axios.post("/api/v1/user/logout");
                  dispatch(setLogout());
                  navigate("/accounts/login");
                } catch {}
              }}
            >
              로그아웃
            </Button>
          )}
        </div>
      </div>
      <div className="Sidebar">
        {isLoggedIn && (
          <Button
            type="primary"
            block
            style={{ marginBottom: "1rem" }}
            onClick={handleClick}
          >
            새 포스팅 쓰기
          </Button>
        )}
        <SuggestionList />
      </div>
      <div className="contents">{children}</div>
      <div className="footer">&copy; YOO HYEON JONG / YANG HEE JAE</div>
    </div>
  );
};

export default AppLayout;
