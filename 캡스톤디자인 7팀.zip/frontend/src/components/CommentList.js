import { Avatar, Tooltip, Input, Button } from "antd";
import { Comment } from "@ant-design/compatible";
import { formatDistance } from "date-fns";
import { useEffect, useState } from "react";
import axios, { useAxios } from "../utils/AxiosInstance";

const CommentList = ({ postId }) => {
  const [commentList, setCommentList] = useState([]);
  const [commentContent, setCommentContent] = useState("");
  const [{ data: originCommentList }, refetch] = useAxios(
    `/api/v1/post/${postId}/comment`
  );
  const now = new Date();

  useEffect(() => {
    if (!originCommentList) {
      setCommentList([]);
    } else {
      setCommentList(originCommentList);
    }
  }, [originCommentList]);

  const handleCommentSave = async () => {
    try {
      await axios.post(`/api/v1/post/${postId}/comment`, {
        message: commentContent,
      });
      setCommentContent("");
      refetch();
    } catch (error) {}
  };

  return (
    <div>
      {commentList.map((comment, idx) => {
        const {
          message: content,
          user: { username: author, avatar },
          updatedAt,
        } = comment;

        return (
          <Comment
            key={idx}
            author={author}
            avatar={<Avatar src={avatar} alt={author} />}
            content={<p>{content}</p>}
            datetime={
              <Tooltip title={updatedAt}>
                <span>
                  {formatDistance(new Date(updatedAt), now, {
                    addSuffix: true,
                  })}
                </span>
              </Tooltip>
            }
          />
        );
      })}

      <Input.TextArea
        style={{ marginBottom: "0.5em" }}
        value={commentContent}
        onChange={(e) => setCommentContent(e.target.value)}
      />
      <Button
        block
        type="primary"
        disabled={commentContent.length === 0}
        onClick={handleCommentSave}
      >
        댓글 쓰기
      </Button>
    </div>
  );
};

export default CommentList;
