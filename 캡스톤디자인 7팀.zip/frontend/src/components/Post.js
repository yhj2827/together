import React from "react";
import { Avatar, Card, Tooltip } from "antd";
import { Comment } from "@ant-design/compatible";
import {
  HeartOutlined,
  HeartTwoTone,
  HeartFilled,
  UserOutlined,
} from "@ant-design/icons";
import { formatDistance } from "date-fns";
import CommentList from "./CommentList";

const Post = ({ post, handleLike }) => {
  const { id: postId, author, caption, location, photo, isLiked } = post;
  const { username, avatar } = author;
  return (
    <div>
      <Card
        hoverable
        cover={<img src={photo} alt={caption} />}
        actions={[
          isLiked ? (
            <HeartFilled
              style={{ color: "red" }}
              onClick={() => handleLike({ post, isLiked: false })}
            />
          ) : (
            <HeartOutlined
              onClick={() => handleLike({ post, isLiked: true })}
            />
          ),
        ]}
      >
        <Card.Meta
          avatar={<Avatar size="large" src={avatar} alt={username} />}
          title={location}
          description={caption}
          style={{ marginBottom: "0.5em" }}
        />
        <hr />
        <CommentList postId={postId} />
      </Card>
    </div>
  );
};

export default Post;
