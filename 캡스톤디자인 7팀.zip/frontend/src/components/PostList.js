import React, { useEffect, useState } from "react";
import Post from "./Post";
import axios, { useAxios } from "../utils/AxiosInstance";
import { Alert } from "antd";

const PostList = () => {
  const [postList, setPostList] = useState([]);
  const [{ data }, refetch] = useAxios("/api/v1/post");

  useEffect(() => {
    if (data) {
      setPostList(data.content);
    }
  }, [data]);

  const handleLike = async ({ post, isLiked }) => {
    const apiUrl = `/api/v1/post/${post.id}/like`;
    const method = isLiked ? "POST" : "DELETE";
    try {
      const response = await axios({
        url: apiUrl,
        method,
      });
      setPostList((prevList) =>
        prevList.map((currentPost) =>
          currentPost === post ? { ...currentPost, isLiked } : currentPost
        )
      );
    } catch (error) {}
  };

  return (
    <div>
      {postList && postList.length === 0 && (
        <Alert type="warning" message="포스팅이 없습니다." />
      )}
      {postList &&
        postList.map((post, idx) => {
          return <Post post={post} key={idx} handleLike={handleLike} />;
        })}
    </div>
  );
};

export default PostList;
