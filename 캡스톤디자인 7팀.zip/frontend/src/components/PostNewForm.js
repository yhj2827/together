import { Form, Input, Button, Modal, Upload, notification } from "antd";
import { useState } from "react";
import { PlusOutlined, SmileOutlined, FrownOutlined } from "@ant-design/icons";
import { getBase64FromFile } from "../utils/base64";
import axios from "../utils/AxiosInstance";
import { useNavigate } from "react-router-dom";

const PostNewForm = () => {
  const navigate = useNavigate();
  const [fileList, setFileList] = useState([]);
  const [previewPhoto, setPreviewPhoto] = useState({
    open: false,
    image: "",
    title: "",
  });
  const [fieldError, setFieldError] = useState({});
  const handleUploadChange = ({ fileList }) => {
    setFileList(fileList);
  };
  const handlePreviewPhoto = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64FromFile(file.originFileObj);
    }

    setPreviewPhoto({
      image: file.url || file.preview,
      open: true,
      title: file.name || file.url.substring(file.url.lastIndexOf("/") + 1),
    });
  };
  const handleFinish = async (values) => {
    const {
      caption,
      location,
      photo: { fileList },
    } = values;

    const formData = new FormData();
    formData.append("caption", caption);
    formData.append("location", location);
    fileList.forEach((file) => {
      formData.append("photo", file.originFileObj);
    });

    try {
      await axios.post("/api/v1/post", formData);

      notification.open({
        message: "포스트 업로드 성공",
        icon: <SmileOutlined style={{ color: "#108ee9" }} />,
      });

      navigate("/");
    } catch (error) {
      notification.open({
        message: "포스트 업로드 실패",
        icon: <FrownOutlined style={{ color: "#FF3333" }} />,
      });
    }
  };
  return (
    <Form
      name="basic"
      labelCol={{
        span: 8,
      }}
      wrapperCol={{
        span: 16,
      }}
      style={{
        maxWidth: 600,
      }}
      initialValues={{
        remember: true,
      }}
      onFinish={handleFinish}
      // onFinishFailed={onFinishFailed}
      autoComplete="off"
    >
      <Form.Item
        label="Caption"
        name="caption"
        rules={[
          {
            required: true,
            message: "Caption을 입력해주세요.",
          },
        ]}
        hasFeedback
        {...fieldError.caption}
      >
        <Input.TextArea />
      </Form.Item>
      <Form.Item
        label="Location"
        name="location"
        rules={[
          {
            required: true,
            message: "Location을 입력해주세요.",
          },
        ]}
        hasFeedback
        {...fieldError.location}
      >
        <Input />
      </Form.Item>

      <Form.Item
        label="Photo"
        name="photo"
        rules={[
          {
            required: true,
            message: "사진을 업로드해주세요.",
          },
        ]}
        hasFeedback
        {...fieldError.photo}
      >
        <Upload
          listType="picture-card"
          fileList={fileList}
          beforeUpload={() => false}
          onChange={handleUploadChange}
          onPreview={handlePreviewPhoto}
        >
          {fileList.length > 0 ? null : (
            <div>
              <PlusOutlined />
              <div className="ant-upload-text">Upload</div>
            </div>
          )}
        </Upload>
      </Form.Item>
      <Form.Item
        wrapperCol={{
          offset: 8,
          span: 16,
        }}
      >
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item>
      <Modal
        open={previewPhoto.open}
        title={previewPhoto.title}
        footer={null}
        onCancel={() => setPreviewPhoto((prev) => ({ open: false }))}
      >
        <img
          alt={previewPhoto.title}
          style={{ width: "100%" }}
          src={previewPhoto.image}
        />
      </Modal>
    </Form>
  );
};

export default PostNewForm;
