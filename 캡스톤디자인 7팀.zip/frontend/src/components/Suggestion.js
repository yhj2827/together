import React from "react";
import { UserOutlined } from "@ant-design/icons";
import { Avatar, Button } from "antd";
import "./Suggestion.scss";

const Suggestion = ({ suggestionUser, onFollowUser }) => {
  const { username, avatar, isFollow } = suggestionUser;
  return (
    <div className="suggestion">
      <div className="avatar">
        <Avatar
          size="small"
          icon={<img src={avatar} alt={`${username}'s avatar`} />}
        />
      </div>
      <div className="username">{username}</div>
      <div className="action">
        {isFollow && "팔로잉 중"}
        {!isFollow && (
          <Button size="small" onClick={() => onFollowUser(username)}>
            Follow
          </Button>
        )}
      </div>
    </div>
  );
};

export default Suggestion;
