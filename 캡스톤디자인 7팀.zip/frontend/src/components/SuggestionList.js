import React, { useEffect, useState } from "react";
import "./SuggestionList.scss";
import Card from "antd/es/card/Card";
import Suggestion from "./Suggestion";
import axios, { useAxios } from "../utils/AxiosInstance";
import { useAppContext } from "../store";

const SuggestionList = ({ style }) => {
  const { store } = useAppContext();
  const [userList, setUserList] = useState([]);
  const [{ data: originUserList }, refetch] = useAxios(
    "/api/v1/user/suggestions",
    {
      manual: true,
    }
  );

  useEffect(() => {
    if (store.isLoggedIn) {
      refetch();
    }
  }, [store.isLoggedIn, refetch]);

  useEffect(() => {
    if (!originUserList) {
      setUserList([]);
    } else {
      setUserList(originUserList.map((user) => ({ ...user, isFollow: false })));
    }
  }, [originUserList]);

  const onFollowUser = (username) => {
    axios
      .post("/api/v1/user/follows", { username })
      .then((response) => {
        setUserList((prevUserList) =>
          prevUserList.map((user) =>
            user.username !== username ? user : { ...user, isFollow: true }
          )
        );
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div style={style}>
      <Card title="Suggestion for you" size="small">
        {store.isLoggedIn &&
          userList &&
          userList.map((suggestionUser) => (
            <Suggestion
              key={suggestionUser.username}
              suggestionUser={suggestionUser}
              onFollowUser={onFollowUser}
            />
          ))}
      </Card>
    </div>
  );
};

export default SuggestionList;
