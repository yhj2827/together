import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { AxiosInterceptor } from "./utils/AxiosInstance";
import "./index.css";
import Root from "./pages";
import { AppProvider } from "./store";
import { ConfigProvider } from "antd";

const config = {
  token: {
    colorPrimary: "#09345D",
  },
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <ConfigProvider theme={config}>
    <BrowserRouter>
      <AppProvider>
        <AxiosInterceptor>
          <Root />
        </AxiosInterceptor>
      </AppProvider>
    </BrowserRouter>
  </ConfigProvider>
);
