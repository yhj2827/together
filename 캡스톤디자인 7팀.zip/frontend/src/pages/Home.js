import React from "react";
import PostList from "../components/PostList";

const Home = () => {
  return <PostList />;
};

export default Home;
