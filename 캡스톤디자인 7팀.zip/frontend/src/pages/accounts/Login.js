import React, { useEffect, useState } from "react";
import axios from "../../utils/AxiosInstance";
import { Card, Form, Input, Button, notification } from "antd";
import { SmileOutlined, FrownOutlined } from "@ant-design/icons";
import { useNavigate, useLocation } from "react-router-dom";
import { setLogin, useAppContext } from "../../store";

const Login = () => {
  const { dispatch } = useAppContext();
  const navigate = useNavigate();
  const location = useLocation();
  const [fieldError, setfieldError] = useState({});

  const from = (location.state && location.state.from) || "/";

  const onFinish = (values) => {
    async function fn() {
      const { username, password } = values;

      setfieldError({});

      const data = { username, password };

      try {
        const response = await axios.post("/api/v1/user/login", data);
        console.log(response);

        dispatch(setLogin());

        notification.open({
          message: "로그인 성공",
          icon: <SmileOutlined style={{ color: "#108ee9" }} />,
        });

        navigate(from);
      } catch (error) {
        if (error.response) {
          notification.open({
            message: "로그인 실패",
            description: "아이디/암호를 확인해주세요.",
            icon: <FrownOutlined style={{ color: "#FF3333" }} />,
          });

          const { data: errorInfo } = error.response;
          if (errorInfo.errorType === "USER_NOT_FOUND") {
            setfieldError({
              username: {
                validateStatus: "error",
                help: errorInfo.message,
              },
            });
          } else if (errorInfo.errorType === "PASSWORD_INCORRECT") {
            setfieldError({
              password: {
                validateStatus: "error",
                help: errorInfo.message,
              },
            });
          }
        }
      }
    }
    fn();
  };
  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  return (
    <Card title="로그인">
      <Form
        name="basic"
        labelCol={{
          span: 8,
        }}
        wrapperCol={{
          span: 16,
        }}
        style={{
          maxWidth: 600,
        }}
        initialValues={{
          remember: true,
        }}
        onFinish={onFinish}
        // onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <Form.Item
          label="Username"
          name="username"
          rules={[
            {
              required: true,
              message: "Please input your username!",
            },
            {
              pattern: /[a-zA-Z0-9._]{3,30}$/,
              message: "3~30자의 영문자, 숫자, ., _를 사용해 주세요.",
            },
          ]}
          hasFeedback
          {...fieldError.username}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Password"
          name="password"
          rules={[
            {
              required: true,
              message: "Please input your password!",
            },
            {
              pattern:
                /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/,
              message:
                "8~16자의 영문 대/소문자, 숫자, 특수문자(@$!%*?&)를 사용해 주세요.",
            },
          ]}
          {...fieldError.password}
        >
          <Input.Password />
        </Form.Item>
        <Form.Item
          wrapperCol={{
            offset: 8,
            span: 16,
          }}
        >
          <Button type="primary" htmlType="submit">
            Submit
          </Button>
          <Button
            type="link"
            htmlType="button"
            onClick={() => navigate("/accounts/signup")}
          >
            Sign up
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default Login;
