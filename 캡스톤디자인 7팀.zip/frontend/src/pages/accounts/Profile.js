import React from "react";

const Profile = () => {
  return <div>accounts/profile</div>;
};

export default Profile;
