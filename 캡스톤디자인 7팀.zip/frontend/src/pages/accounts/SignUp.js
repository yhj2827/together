import React, { useEffect, useState } from "react";
import axios from "../../utils/AxiosInstance";
import { Form, Input, Button, notification } from "antd";
import { SmileOutlined, FrownOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";

const SignUp = () => {
  const navigate = useNavigate();
  const [fieldError, setfieldError] = useState({});

  const onFinish = (values) => {
    async function fn() {
      const { username, password } = values;

      setfieldError({});

      const data = { username, password };

      try {
        await axios.post("/api/v1/user/join", data);

        notification.open({
          message: "회원가입 성공",
          description: "로그인 페이지로 이동합니다.",
          icon: <SmileOutlined style={{ color: "#108ee9" }} />,
        });

        navigate("/accounts/login");
      } catch (error) {
        if (error.response) {
          notification.open({
            message: "회원가입 실패",
            description: "아이디/암호를 확인해주세요.",
            icon: <FrownOutlined style={{ color: "#FF3333" }} />,
          });

          const { data: errorInfo } = error.response;
          if (errorInfo.errorType === "USERNAME_CONFLICT") {
            setfieldError({
              username: {
                validateStatus: "error",
                help: errorInfo.message,
              },
            });
          }
        }
      }
    }
    fn();
  };
  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  return (
    <Form
      name="basic"
      labelCol={{
        span: 8,
      }}
      wrapperCol={{
        span: 16,
      }}
      style={{
        maxWidth: 600,
      }}
      initialValues={{
        remember: true,
      }}
      onFinish={onFinish}
      // onFinishFailed={onFinishFailed}
      autoComplete="off"
    >
      <Form.Item
        label="Username"
        name="username"
        rules={[
          {
            required: true,
            message: "Please input your username!",
          },
          {
            pattern: /[a-zA-Z0-9._]{3,30}$/,
            message: "3~30자의 영문자, 숫자, ., _를 사용해 주세요.",
          },
        ]}
        hasFeedback
        {...fieldError.username}
      >
        <Input />
      </Form.Item>

      <Form.Item
        label="Password"
        name="password"
        rules={[
          {
            required: true,
            message: "Please input your password!",
          },
          {
            pattern:
              /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/,
            message:
              "8~16자의 영문 대/소문자, 숫자, 특수문자(@$!%*?&)를 사용해 주세요.",
          },
        ]}
        {...fieldError.password}
      >
        <Input.Password />
      </Form.Item>
      <Form.Item
        wrapperCol={{
          offset: 8,
          span: 16,
        }}
      >
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item>
    </Form>
  );
};

export default SignUp;
