import React from "react";
import { Routes, Route } from "react-router-dom";
import Profile from "./Profile";
import Login from "./Login";
import RouteNoMatch from "../global/RouteNoMatch";
import SignUp from "./SignUp";

const AccountsRoutes = () => {
  return (
    <Routes>
      <Route path="/profile" element={<Profile />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<SignUp />} />
      <Route path="*" element={<RouteNoMatch />} />
    </Routes>
  );
};

export default AccountsRoutes;
