import React, { useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import AppLayout from "../components/AppLayout";
import Home from "./Home";
import About from "./About";
import AccountsRoutes from "./accounts/index";
import RouteNoMatch from "./global/RouteNoMatch";
import { setLogin, setLogout, useAppContext } from "../store";
import axios from "../utils/AxiosInstance";
import PostNew from "./PostNew";
import { AppProvider } from "../store";
import { AxiosInterceptor } from "../utils/AxiosInstance";

const Root = () => {
  const { dispatch } = useAppContext();
  useEffect(() => {
    axios
      .get("/api/v1/user/status")
      .then((response) => {
        dispatch(setLogin());
      })
      .catch((error) => {
        dispatch(setLogout());
      });
  }, []);

  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/accounts/*" element={<AccountsRoutes />} />
        <Route path="/posts/new" element={<PostNew />} />
        <Route path="*" element={<RouteNoMatch />} />
      </Routes>
    </AppLayout>
  );
};

export default Root;
