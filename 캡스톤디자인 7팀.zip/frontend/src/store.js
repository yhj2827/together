import React, { createContext, useContext, useReducer } from "react";

const initialState = {
  jwtToken: "",
  isLoggedIn: false,
};

const AppContext = createContext();

const reducer = (prevState, action) => {
  const { type } = action;
  if (type === SET_TOKEN) {
    const { payload: jwtToken } = action;
    return {
      ...prevState,
      jwtToken,
    };
  } else if (type === DELETE_TOKEN) {
    return {
      ...prevState,
      jwtToken: "",
    };
  } else if (type === SET_LOGIN) {
    return {
      ...prevState,
      isLoggedIn: true,
    };
  } else if (type === SET_LOGOUT) {
    return {
      ...prevState,
      isLoggedIn: false,
    };
  }
  return prevState;
};

export const AppProvider = ({ children }) => {
  const [store, dispatch] = useReducer(reducer, initialState);
  return (
    <AppContext.Provider value={{ store, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => useContext(AppContext);

// Actions
const SET_TOKEN = "APP/SET_TOKEN";
const DELETE_TOKEN = "APP/DELETE_TOKEN";
const SET_LOGIN = "APP/SET_LOGIN";
const SET_LOGOUT = "APP/SET_LOGOUT";

// Action Creators
export const setToken = (token) => ({ type: SET_TOKEN, payload: token });
export const deleteToken = () => ({ type: DELETE_TOKEN });
export const setLogin = () => ({ type: SET_LOGIN });
export const setLogout = () => ({ type: SET_LOGOUT });
