import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import { makeUseAxios } from "axios-hooks";
import { setLogout, useAppContext } from "../store";
import { API_HOST } from "../Constants";

const axiosInstance = axios.create({
  baseURL: API_HOST,
  withCredentials: true,
});

const useAxios = makeUseAxios({
  axios: axiosInstance,
});

const AxiosInterceptor = ({ children }) => {
  const { dispatch } = useAppContext();
  const navigate = useNavigate();
  const location = useLocation();
  const [isSet, setIsSet] = useState(false);

  useEffect(() => {
    const interceptor = axiosInstance.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response && error.response.status === 403) {
          dispatch(setLogout());
          navigate("/accounts/login", { state: { from: location.pathname } });
        }
        return Promise.reject(error);
      }
    );
    setIsSet(true);

    return () => {
      axiosInstance.interceptors.response.eject(interceptor);
    };
  }, [navigate]);

  return isSet && children;
};

export default axiosInstance;
export { useAxios, AxiosInterceptor };
